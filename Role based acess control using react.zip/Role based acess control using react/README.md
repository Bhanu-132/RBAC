
# Project Title

A brief description of what this project does and who it's for


## Documentation
    Role-Based Access Control (RBAC) UI.

Ive choosen framework as react.

[Documentation](https://linktodocumentation)


## Installation

Install my-project with npm

```bash
  npm install my-project
  cd my-project
```
    


## Tech Stack

**Client:** React, Redux, TailwindCSS

**Server:** Node, Express, React






## Support

Ive took the help of youtube to do it.


## Related

Here are some related projects

[Awesome README](https://github.com/matiassingers/awesome-readme)

